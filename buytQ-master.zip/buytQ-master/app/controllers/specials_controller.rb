class SpecialsController < ApplicationController
  def index
    @specials = Special.all
    
  end
  #to make the show action to show a menu/recipe clicked for more description.or more details
  def show
      #to find something by the id. same as request arrays in Php..params is the same
      @special = Special.find(params[:id])
  end
  def new
    @special = Special.new
  end
  def create
    @special =Special.new(special_params)
    @special.trader = Trader.find(0)
    
    if @special.save
      flash[:success] = "Special was successfully created."
      redirect_to specials_path
    else
      render :new
    end
    #http://stackoverflow.com/questions/22566072/rails-4-flash-notice
    
       #to check params--click the create button and enter params in the terminal
  end
   #strong params--way to do it is by doing a method
   private
      def special_params
        params.require(:special).permit(:special_item, :special_description, :special_price)
      end
end
#to relaod a rails console just type reload! to make sure all the updates are available