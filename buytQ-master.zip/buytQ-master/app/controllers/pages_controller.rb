class PagesController < ApplicationController
  def home
    redirect_to menus_path if logged_in?
    
  end
end