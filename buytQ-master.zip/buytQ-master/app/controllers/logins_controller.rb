class LoginsController < ApplicationController
    def new
        #login doesnot need any object. It is session which is just that the information is stored in cookies.
        #for run time errors use gem the rubyracer
        #http://stackoverflow.com/questions/13530042/execjsruntimeerror-in-usersindex-ror
    end
    def create
        trader = Trader.find_by(email: params[:email])
         if trader && trader.authenticate(params[:password])
             session[:trader_id] = trader.id
             flash[:success] = "You are logged in."
             redirect_to menus_path
             
         else
             flash.now[:danger] = "Your email address or password does not match"
             render 'new'
             
             
         end
    end
    def destroy
        session[:trader_id] = nil
        flash[:success] = "You have logged out."
        redirect_to root_path
    end

end