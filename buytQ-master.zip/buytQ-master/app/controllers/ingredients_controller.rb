class IngredientsController < ApplicationController
    before_action :require_user,except: [:show]
    def show
        @ingredient = Ingredient.find(params[:id])
        @menus = @ingredient.menu.paginate(page: params[:page],per_page: 4)
    end
    def new
        @ingredient = Ingredient.new
    end 
    def create
        @ingredient = Ingredient.new(ingredient_params)
        if @ingredient.save
      flash[:success] = "Ingredient was successfully created."
      redirect_to menus_path
        else
            #to display an error
      render :new
        end
    end 
    
    private
        def ingredient_params
            params.require(:ingredient).permit(:name)
        end
    
end