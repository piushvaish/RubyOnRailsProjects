class TradersController < ApplicationController
  #before_action is used for every action.ordering is very important
  before_action :set_trader,only: [:edit, :update, :show]
  before_action :require_same_user,only: [:edit, :update]
  
  def index
    
    @traders = Trader.paginate(page: params[:page], per_page: 3)
    
  end
  #to make the show action to show a menu/recipe clicked for more description.or more details
  def show
      #to find something by the id. same as request arrays in Php..params is the same
      @trader = Trader.find(params[:id])
  end
  def new
    @trader = Trader.new
  
  end
  def create
    @trader =Trader.new(trader_params)
    if @trader.save
      flash[:success] = "Your account has been created."
      session[:trader_id] = @trader.id #when account is created, user is logged in
      redirect_to menus_path
    else
      render :new
    end
    
  end
  def edit
     
  end
  def update
    
    if @trader.update(trader_params)
    # to do flash success error is getting repeated
      flash[:success] = "Your profile was updated successfully."
      redirect_to trader_path(@trader) # todo show trader page
      
    else
      #flash.now[:error] = "Could not save client" try to see if it works
      render 'edit'
    end
  end
  
  def show
    
    @menus = @trader.menus.paginate(page: params[:page], per_page: 3)
  end
  private
   #private methods. and have to be indented once after private
      def trader_params
        params.require(:trader).permit(:name, :location, :opening_hours, :summary, :cuisine, :contact_name, :address, :phone, :email, :password)
      end
      def set_trader
        @trader = Trader.find(params[:id])
        
      end
      def require_same_user
        if current_user != @trader
         flash[:danger] = "You can only edit your own menu" 
         redirect_to root_path
        end
      
      end
end
