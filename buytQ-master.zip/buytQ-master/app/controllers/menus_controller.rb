class MenusController < ApplicationController
  before_action :set_menu,only: [:edit, :update, :show, :like]
  #require user method is in application controller to ensure it can be accessed by every application
  before_action :require_user,except: [:index, :show, :like]
  before_action :require_user_like ,only: [:like]
  before_action :require_same_user,only: [:edit, :update]
  before_action :admin_user,only: :destroy
  def index
    # @menus = Menu.all.sort_by{|likes| likes.thumbs_up_total}.reverse
    # for pagination ..display a certain amount on one page
    #@menus = Menu.paginate(page: params[:page], per_page: 4)
    #very importanr..to start a server
    
    @menus = Menu.paginate(:page => params[:page], :per_page => 4) 
   # @menus = Menu.paginate(page: params[:page], per_page: 4)
    
    
  end
  #to make the show action to show a menu/recipe clicked for more description.or more details
  def show
      #to find something by the id. same as request arrays in Php..params is the same
      
  end
  def new
    @menu = Menu.new
  end
  def create
    @menu =Menu.new(menu_params)
    @menu.trader = current_user
    
    
    if @menu.save
      flash[:success] = "Menu was successfully created."
      redirect_to menus_path
    else
      render :new
    end
    #http://stackoverflow.com/questions/22566072/rails-4-flash-notice
    
       #to check params--click the create button and enter params in the terminal
  end
  def edit
    
  end
  #changed it to show menu show page after editing a menu item
  def update
    
    if @menu.update(menu_params)
      flash[:success] = "Your menu was updated successfully."
      redirect_to menu_path(@menu)
    else
      render :edit
    end
  end
  #for like and dislike
  def like
    
    like = Like.create(likes: params[:like], trader: current_user ,menu: @menu)
    if like.valid?
     flash[:success] = "Your selection was successful"
     redirect_to :back
    else
      flash[:danger] = "You can like/dislike a menu item just once"
      redirect_to :back
      
    end
    
  end
  #to delete a menu item
  def destroy
    Menu.find(params[:id]).destroy
    flash[:success] = "Menu item deleted"
     redirect_to menus_path
    
  end
   #strong params--way to do it is by doing a method..and assigning a menu item to one of the styles and ingredients
  private
      def menu_params
        params.require(:menu).permit(:menu_item, :item_description, :price, :picture,style_ids: [],ingredient_ids: [])
      end
      def set_menu
        @menu = Menu.find(params[:id])
        
      end
      def require_same_user
        #as we are in menu controller,hence we need menu is required..and menu is set before this 
        if (current_user != @menu.trader && !current_user.admin?) #if not menu's user and not an admin
         flash[:danger] = "You can only edit your own menu" 
         redirect_to menu_path
        end
      end
      
      def require_user_like
    
         if !logged_in?
          flash[:danger] = "You must be logged in to perform that action!" 
          redirect_to :back
         end
      end
      
      def admin_user
        redirect_to menus_path unless current_user.admin?
      end 
end
#to relaod a rails console just type reload! to make sure all the updates are available
