class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception
  
  helper_method :current_user, :logged_in?
  
  def current_user
    #for memorization.more like a cache where the session doesnot have to look again and again for trader_id.||=
   @current_user ||= Trader.find(session[:trader_id]) if session[:trader_id]
  end
  def logged_in?
    # a boolean for seeing if it the current user
    #to redirect to the traders profile page use ----trader_path(current_user) if logged_in?
    
    !!current_user # using current_user function; return true if @current_user, which is returned from func current_user, is not nul
  end
  
   def require_user
    
    if !logged_in?
     flash[:danger] = "You must be logged in to perform that action!" 
     redirect_to menus_path
    end
   end
  
end
