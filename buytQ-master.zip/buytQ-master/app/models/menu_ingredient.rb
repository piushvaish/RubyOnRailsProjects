class MenuIngredient < ActiveRecord::Base
    belongs_to :menu, touch: true
    belongs_to :ingredient

end