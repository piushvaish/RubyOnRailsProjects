class Menu < ActiveRecord::Base
  belongs_to :trader
  has_many :likes, dependent: :destroy
  has_many :menu_styles, dependent: :destroy
  has_many :styles,through: :menu_styles
  has_many :menu_ingredients, dependent: :destroy
  has_many :ingredients,through: :menu_ingredients
  validates :trader_id, presence: true
  validates :menu_item, presence: true,length: { minimum: 2,maximum: 50 }
  validates :item_description, presence: true,length: { minimum: 15,maximum: 500 }
  validates :price, presence: true,length: { minimum: 2,maximum: 40 },numericality: { only_integer: false }
  mount_uploader :picture, PictureUploader #PictureUploader is name of the class in picture_uploader.rb
  validate :picture_size
  #to order by likes.. add a column in the model and add them and order by the number of likes
  default_scope -> { order(updated_at: :desc) }
  # for totalling the number of likes
  def thumbs_up_total
    self.likes.where(likes: true).size
  end
  def thumbs_down_total
    self.likes.where(likes: false).size
    
  end

  
  private
    def picture_size
      if picture.size > 5.megabytes
        errors.add(:picture, "should be less than 5 MB")
      end 
    end
end