class Special < ActiveRecord::Base
  has_many :likes
  belongs_to :trader
  validates :trader_id, presence: true
  validates :special_item, presence: true,length: { minimum: 2,maximum: 50 }
  validates :special_description, presence: true,length: { minimum: 15,maximum: 500 }
  validates :special_price, presence: true,length: { minimum: 2,maximum: 40 },numericality: { only_integer: false }
end