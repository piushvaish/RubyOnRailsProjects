class Style < ActiveRecord::Base
    has_many :menu_styles
    has_many :menus,through: :menu_styles
    validates :name, presence: true,length: { minimum: 2,maximum: 25 }

end