class Trader < ActiveRecord::Base
  has_many :menus
  has_many :specials
  has_many :likes
  validates :name, presence: true,length: { minimum: 2,maximum: 50 }
  before_save {self.email = email.downcase}
  validates :email, presence: true,length: { maximum: 100 },uniqueness: { case_sensitive: false }, :format => /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i
  validates :cuisine, presence: true,length: { minimum: 2,maximum: 15 }
  validates :summary, presence: true,length: { minimum: 5,maximum: 500 }
  validates :address, presence: true,length: { minimum: 2,maximum: 500 }
  validates :phone, presence: true,length: { minimum: 2,maximum: 40 },numericality: { only_integer: true }
  validates :location, presence: true,length: {minimum: 2,maximum: 500 }
  validates :opening_hours, presence: true,length: { minimum: 2,maximum: 40 }
  # to check the errors when saving add create! and will help to see error messages
  #(http://stackoverflow.com/questions/19037733/why-does-my-rails-rollback-when-i-try-to-user-save)
  #for authentication
  has_secure_password
end