class MenuStyle < ActiveRecord::Base
    belongs_to :menu
    belongs_to :style

end