class Ingredient < ActiveRecord::Base
    validates :name, presence: true,length: { minimum: 2,maximum: 25 }
    has_many :menu_ingredients
    has_many :menu,through: :menu_ingredients

end