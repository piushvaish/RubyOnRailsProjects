class Like < ActiveRecord::Base
    belongs_to :trader
    belongs_to :menu
    belongs_to :special
    validates_uniqueness_of :trader,scope: :menu
end