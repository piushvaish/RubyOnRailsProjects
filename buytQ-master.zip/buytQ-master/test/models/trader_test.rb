require "test_helper"
class TraderTest < ActiveSupport::TestCase
  def setup
      @trader = Trader.new(name: "John",location: "Ranelagh", opening_hours: "10-5",summary: "Going all out on a theme, Dillinger's American Diner has a menu packed with novelty named burgers stacked with a 6 or 8oz patty, smokey beans, cheese, bacon and more.",cuisine: "American Diner",address: "47 Ranelagh, Dublin",phone: "+35314978010",email:"john@example.com")
  end
 # for assert , do not use asser@trader.valid?(http://stackoverflow.com/questions/16116436/rails-failed-assertion-no-message-given)
  test "trader should be valid" do
  @trader.valid?
  end
  #name
  test "name should be present" do
    @trader.name = ""
   assert_not @trader.valid?
  end
  test "name should not too short" do
    @trader.name = "a" 
   assert_not @trader.valid?
  end
  test "name should not too long" do
    @trader.name = "a" * 101
   assert_not @trader.valid?
  end
  #location
  test "location should be present" do
    @trader.location = ""
   assert_not @trader.valid?
  end
  test "location should not too short" do
    @trader.location = "a" 
   assert_not @trader.valid?
  end
  test "location should not too long" do
    @trader.location = "a" * 501
   assert_not @trader.valid?
  end
  #opening_hours
  test "opening_hours should be present" do
    @trader.opening_hours = ""
   assert_not @trader.valid?
  end
  test "opening_hours should not too short" do
    @trader.opening_hours = "a" 
   assert_not @trader.valid?
  end
  test "opening_hours should not too long" do
    @trader.opening_hours = "a" * 101
   assert_not @trader.valid?
  end
  #summary
  test "summary should be present" do
    @trader.summary = ""
   assert_not @trader.valid?
  end
  test "summary should not too short" do
    @trader.summary = "a" 
   assert_not @trader.valid?
  end
  test "summary should not too long" do
    @trader.summary = "a" * 501
   assert_not @trader.valid?
  end
  #address
  test "address should be present" do
    @trader.address = ""
   assert_not @trader.valid?
  end
  test "address should not too short" do
    @trader.address = "a" 
   assert_not @trader.valid?
  end
  test "address should not too long" do
    @trader.address = "a" * 501
   assert_not @trader.valid?
  end
  #cuisine
  test "cuisine should be present" do
    @trader.cuisine = ""
   assert_not @trader.valid?
  end
  test "cuisine should not too short" do
    @trader.cuisine = "a" 
   assert_not @trader.valid?
  end
  test "cuisine should not too long" do
    @trader.cuisine = "a" * 101
   assert_not @trader.valid?
  end
  #phone
  test "phone should be present" do
    @trader.phone = ""
   assert_not @trader.valid?
  end
  test "phone should not too short" do
    @trader.phone = "a" 
   assert_not @trader.valid?
  end
  test "phone should not too long" do
    @trader.phone = "a" * 101
   assert_not @trader.valid?
  end
  #email
  test "email should be present" do
    @trader.email = ""
   assert_not @trader.valid?
  end

  test "email should not too long" do
    @trader.email = "a" * 101 + "@example.com"
   assert_not @trader.valid?
  end
  test "email should be unique" do
      dup_trader = @trader.dup
      dup_trader.email =@trader.email.upcase
      @trader.save
      assert_not dup_trader.valid?
      
  end
  #
  test "email validation should accept valid addresses" do
    valid_addresses = %w[user@eee.com R_TDD-DS@eee.hello.org user@example.com first.last@eem.au laura+joe@monk.cm]
    valid_addresses.each do |va|
    @trader.email = va
    @trader.valid? '#{va.inspect} should be valid'
    end
  end
  test "email validation should reject invalid addresses" do
    invalid_addresses = %w[user@example,com user_at_eee.org user.name@example. eee@i_am_.com foo@ee+aar.com]
    invalid_addresses.each do |ia|
    @trader.email = ia
    assert_not @trader.valid?, '#{ia.inspect} should be invalid'
    end
  end
end
  
  