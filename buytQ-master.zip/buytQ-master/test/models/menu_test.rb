require "test_helper"
class MenuTest < ActiveSupport::TestCase
  def setup
    @trader = Trader.create(name: "John",location: "Ranelagh", opening_hours: "10-5",summary: "Going all out on a theme, Dillinger's American Diner has a menu packed with novelty named burgers stacked with a 6 or 8oz patty, smokey beans, cheese, bacon and more.",cuisine: "American Diner",address: "47 Ranelagh, Dublin",phone: "+35314978010",email:"john@example.com")
    @menu = @trader.menus.build(menu_item: "El Gringo",item_description: "Crispy nachos with smoked chilli beef, guacamole, sour cream & melted cheese",price:"12.00")
  end
  test "menu should be valid" do
  assert @menu.valid?
  end
  test "trader_id should be present" do
    @menu.trader_id = ""
   assert_not @menu.valid?
 end
  #menuItem
  test "menu_item should be present" do
    @menu.menu_item = ""
   assert_not @menu.valid?
  end
  test "menu_item should not too short" do
    @menu.menu_item = "a" 
   assert_not @menu.valid?
  end
  test "menu_item should not too long" do
    @menu.menu_item = "a" * 101
   assert_not @menu.valid?
  end
  #item_description
  
  test "item_description should be present" do
    @menu.item_description = ""
   assert_not @menu.valid?
  end
  test "item_description should not too short" do
    @menu.item_description = "a" 
   assert_not @menu.valid?
  end
  test "item_description should not too long" do
    @menu.item_description = "a" * 501
   assert_not @menu.valid?
  end
  #prie
  
  test "price should be present" do
    @menu.price = ""
   assert_not @menu.valid?
  end
  test "price should not too short" do
    @menu.price = "a" 
   assert_not @menu.valid?
  end
  test "price should not too long" do
    @menu.price = "a" * 101
   assert_not @menu.valid?
  end
  
end