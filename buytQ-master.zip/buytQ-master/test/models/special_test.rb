require "test_helper"
class SpecialTest < ActiveSupport::TestCase
  def setup
    @trader = Trader.create(name: "John",location: "Ranelagh", opening_hours: "10-5",summary: "Going all out on a theme, Dillinger's American Diner has a menu packed with novelty named burgers stacked with a 6 or 8oz patty, smokey beans, cheese, bacon and more.",cuisine: "American Diner",address: "47 Ranelagh, Dublin",phone: "+35314978010",email:"john@example.com")
    @special = @trader.specials.build(special_item: "El Gringo",special_description: "Crispy nachos with smoked chilli beef, guacamole, sour cream & melted cheese",special_price:"12.00")
  end
  test "special should be valid" do
  assert @special.valid?
  end
  test "trader_id should be present" do
    @special.trader_id = ""
   assert_not @special.valid?
  end
  #specialItem
  test "special_item should be present" do
    @special.special_item = ""
   assert_not @special.valid?
  end
  test "special_item should not too short" do
    @special.special_item = "a" 
   assert_not @special.valid?
  end
  test "special_item should not too long" do
    @special.special_item = "a" * 101
   assert_not @special.valid?
  end
  #item_description
  
  test "item_description should be present" do
    @special.special_description = ""
   assert_not @special.valid?
  end
  test "item_description should not too short" do
    @special.special_description = "a" 
   assert_not @special.valid?
  end
  test "item_description should not too long" do
    @special.special_description = "a" * 501
   assert_not @special.valid?
  end
  #prie
  
  test "price should be present" do
    @special.special_price = ""
   assert_not @special.valid?
  end
  test "price should not too short" do
    @special.special_price = "a" 
   assert_not @special.valid?
  end
  test "price should not too long" do
    @special.special_price = "a" * 101
   assert_not @special.valid?
  end
  
end