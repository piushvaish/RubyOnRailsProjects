Rails.application.routes.draw do
 root 'pages#home'
 get '/home', to:'pages#home'
 resources :traders,except: [:new]
 #for registering traders
 get '/register', to:'traders#new'
 #for log in/log ou/ and close session. It is done by uniqueness of the email ,howver it can be done by name as well.
 #for controller to go to a path it is always singular.hence http://www.abc.com/login not logins
 get '/login', to:'logins#new'
 post '/login', to:'logins#create'
 get '/logout', to:'logins#destroy'
 
 #for nested like routes
 resources :menus do
  member do
   post 'like'
  end
 end
 resources :specials
 resources :styles,only: [:new, :create, :show]
 resources :ingredients,only: [:new, :create, :show]
 get '/signupfor newsletter/', to: 'signupfor#show', as: 'newsletter'
get '/blog/', to: 'blog#show', as: 'blog'
get '/contact/', to: 'contact#show', as: 'contact'
get '/acknowledgement/', to: 'acknowledgement#show', as: 'acknowledgement'
get '/privacy/', to: 'privacy#show', as: 'privacy'
get '/year/', to: 'year#show', as: 'year'
get '/eula/', to: 'eula#show', as: 'eula'
get '/sitemap/', to: 'sitemap#show', as: 'sitemap'

end
