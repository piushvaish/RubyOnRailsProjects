class CreateMenuStyles < ActiveRecord::Migration
  def change
    create_table :menu_styles do |t|
      t.integer :style_id, :menu_id
    end
  end
end
