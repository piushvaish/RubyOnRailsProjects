class AddPasswordDigestToTraders < ActiveRecord::Migration
  def change
    #has to be password digest
    add_column :traders, :password_digest, :string
  end
end







