class AddIdToMenuSpecials < ActiveRecord::Migration
  def change
    add_column :menus, :trader_id, :integer
    add_column :specials, :trader_id, :integer
  end
end
