class AddPicturesToMenus < ActiveRecord::Migration
  def change
    add_column :menus, :picture, :string
  end
end
