class CreateTraders < ActiveRecord::Migration
  def change
    create_table :traders do |t|
    t.string   :name
    t.string   :location
    t.string   :opening_hours
    t.text     :summary
    t.string   :cuisine
    t.string   :contact_name
    t.text     :address
    t.string   :phone
    t.string   :email
    t.timestamps
    end
  end
end
