class CreateLikes < ActiveRecord::Migration
  def change
    create_table :likes do |t|
      t.boolean :likes
      t.integer :trader_id, :menu_id, :special_id
      t.timestamps
    end
  end
end
