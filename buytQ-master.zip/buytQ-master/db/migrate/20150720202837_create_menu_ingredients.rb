class CreateMenuIngredients < ActiveRecord::Migration
  def change
    create_table :menu_ingredients do |t|
      t.integer :ingredient_id, :menu_id
    end
  end
end
