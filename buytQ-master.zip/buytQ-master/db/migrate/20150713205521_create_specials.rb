class CreateSpecials < ActiveRecord::Migration
  def change
    create_table :specials do |t|
    t.string   :special_item
    t.text     :special_description
    t.decimal  :special_price
    t.timestamps
    end
  end
end
