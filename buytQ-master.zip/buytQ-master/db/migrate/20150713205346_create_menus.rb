class CreateMenus < ActiveRecord::Migration
  def change
    create_table :menus do |t|
    t.string   :menu_item
    t.text     :item_description
    t.decimal  :price
    t.timestamps
    end
  end
end
#very good for rollback..to revert to older rake db:migrate:down VERSION=20100905201547