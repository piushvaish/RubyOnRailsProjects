require "test_helper"

class MarketTest < ActiveSupport::TestCase
  
  def setup
    @market =Market.new(location:"Dublin",day:'sunday',date:'12/04/2014',time:'13.40',market_email:'abcd@gmail.com')
    
  end
  test "market should be valid" do
    assert @market.valid?
  end
  test "location should be present" do
    @market.location= ''
     assert_not @market.valid?
    
  end
  test "location should not be too long" do
    @market.location= 'a'* 101
     assert_not @market.valid?
    
  end
  test "location length should not be too short" do
    @market.location= 'aaa'
     assert_not @market.valid?
    
  end
  
  
  test "day should not be too short" do
    @market.day= 'aa'
     assert_not @market.valid?
    
  end
  test "day should not be too long" do
    @market.day= 'a'*12
     assert_not @market.valid?
    
  end
  
end