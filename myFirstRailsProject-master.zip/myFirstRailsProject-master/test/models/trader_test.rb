require "test_helper"

class TraderTest < ActiveSupport::TestCase
  def setup 
    @trader =Trader.new(trader_name:'john',bio:'this is for the test',cuisine:'indian',phone_number:'0861234567',trader_email:'john@example.com')
  end
  
  test "trader_name should be valid" do
    assert @trader.valid?
  end
  test "trader should be present" do
    @trader.trader_name= ''
     assert_not @trader.valid?
    
  end
  test "trader_name should not be too long" do
    @trader.trader_name= 'a'* 40
     assert_not @trader.valid?
    
  end
  test "trader_name length should not be too short" do
    @trader.trader_name= 'aaa'
     assert_not @trader.valid?
    
  end
  test "email should be in the correct format" do
    valid_addresses = %w[user@eee.com R_TDD-DS@eee.hello.org user@example.com first.last@eem.au laura+joe@monk.cm]
    valid_addresses.each do |i|
      @trader.trader_email = i
      assert @trader.valid?, '#{i.inspect} should be valid'
      end
    end
    test "email should not be in the correct format" do
    invalid_addresses = %w[user,xample.com users.name!xample.com hey7hhh.hhh.com]
    invalid_addresses.each do |i|
      @trader.trader_email = i
      assert_not @trader.valid?, '#{i.inspect} should be invalid'
      end
    end
      test "email address uniqueness regardless of case" do
       dup_trader = Trader.new(trader_name: "First Last")
      assert_not dup_trader.valid?

    end
end

