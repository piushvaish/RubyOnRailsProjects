class Venue < ActiveRecord::Base
end