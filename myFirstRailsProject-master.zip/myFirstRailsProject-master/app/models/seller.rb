class Seller < ActiveRecord::Base
end