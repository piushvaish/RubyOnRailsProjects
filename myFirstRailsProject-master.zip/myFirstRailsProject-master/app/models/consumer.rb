class Consumer < ActiveRecord::Base
end