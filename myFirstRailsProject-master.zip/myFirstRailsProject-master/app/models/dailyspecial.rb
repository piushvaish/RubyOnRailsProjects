class Dailyspecial < ActiveRecord::Base
end