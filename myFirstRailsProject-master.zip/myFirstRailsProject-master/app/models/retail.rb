class Retail < ActiveRecord::Base
end