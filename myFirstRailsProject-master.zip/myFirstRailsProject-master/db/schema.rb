# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20150707204149) do

  create_table "consumers", force: :cascade do |t|
    t.string   "consumers_name"
    t.string   "c_phone"
    t.string   "c_email"
    t.text     "order_history"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "food_id"
    t.integer  "dailyspecial_id"
  end

  create_table "customers", force: :cascade do |t|
    t.string   "name"
    t.string   "email"
    t.string   "customer_phone_number"
    t.text     "history"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "customer_id"
  end

  create_table "dailyspecials", force: :cascade do |t|
    t.string   "daily_item"
    t.text     "dailyitem_description"
    t.decimal  "price"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "seller_id"
  end

  create_table "foods", force: :cascade do |t|
    t.string   "menu_item"
    t.text     "item_description"
    t.decimal  "price"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "seller_id"
  end

  create_table "locations", force: :cascade do |t|
    t.string   "name"
    t.string   "street"
    t.string   "county"
    t.string   "country"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "location_id"
  end

  create_table "markets", force: :cascade do |t|
    t.string   "day"
    t.string   "market_email"
    t.integer  "market_id"
    t.string   "market_name"
    t.string   "market_phone"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "date"
  end

  create_table "menus", force: :cascade do |t|
    t.string   "dailyspecials"
    t.string   "menuItems"
    t.text     "decription"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "menu_id"
    t.decimal  "price"
  end

  create_table "retails", force: :cascade do |t|
    t.string   "retail_name"
    t.string   "day"
    t.string   "date"
    t.text     "description"
    t.string   "contact_name"
    t.string   "retail_phone"
    t.string   "retail_email"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "venue_id"
  end

  create_table "sellers", force: :cascade do |t|
    t.string   "sellers_name"
    t.text     "summary"
    t.string   "cuisine"
    t.string   "seller_contact_name"
    t.string   "seller_phone"
    t.string   "seller_email"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "venue_id"
  end

  create_table "traders", force: :cascade do |t|
    t.string   "trader_name"
    t.text     "bio"
    t.string   "cuisine"
    t.string   "phone_number"
    t.string   "trader_email"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "trader_id"
  end

  create_table "venues", force: :cascade do |t|
    t.string   "venue_name"
    t.string   "address"
    t.string   "county"
    t.string   "country"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
