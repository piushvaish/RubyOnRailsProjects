class CreateSellers < ActiveRecord::Migration
  def change
    create_table :sellers do |t|
    t.string   :sellers_name
    t.text     :summary
    t.string   :cuisine
    t.string   :seller_contact_name
    t.string   :seller_phone
    t.string   :seller_email
    t.timestamps
    end
  end
end
