class AddIdRetails < ActiveRecord::Migration
  def change
    add_column :sellers, :venue_id, :integer
    add_column :retails, :venue_id, :integer
    add_column :foods, :seller_id, :integer
    add_column :dailyspecials, :seller_id, :integer
    add_column :consumers, :food_id, :integer
    add_column :consumers, :dailyspecial_id, :integer
    
  end
end
