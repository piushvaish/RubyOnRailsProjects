class CreateVenues < ActiveRecord::Migration
  def change
    create_table :venues do |t|
    t.string   :venue_name
    t.string   :address
    t.string   :county
    t.string   :country
    t.timestamps
    end
  end
end
