class CreateRetails < ActiveRecord::Migration
  def change
    create_table :retails do |t|
    t.string   :retail_name
    t.string   :day
    t.string   :date
    t.text     :description
    t.string   :contact_name
    t.string   :retail_phone
    t.string   :retail_email
    t.timestamps
    end
  end
end
