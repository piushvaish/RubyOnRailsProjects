class CreateConsumers < ActiveRecord::Migration
  def change
    create_table :consumers do |t|
    t.string   :consumers_name
    t.string   :c_phone
    t.string   :c_email
    t.text     :order_history
    t.timestamps
    end
  end
end
