class CreateDailyspecials < ActiveRecord::Migration
  def change
    create_table :dailyspecials do |t|
    t.string   :daily_item
    t.text     :dailyitem_description
    t.decimal  :price
    t.timestamps
    end
  end
end
