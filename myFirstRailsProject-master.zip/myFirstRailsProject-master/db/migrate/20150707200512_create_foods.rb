class CreateFoods < ActiveRecord::Migration
  def change
    create_table :foods do |t|
    t.string   :menu_item
    t.text     :item_description
    t.decimal  :price
    t.timestamps
    end
  end
end
